CREATE TABLE purchases(
    id INTEGER,
    username TEXT NOT NULL,
    stock_symbol TEXT NOT NULL,
    price FLOAT NOT NULL,
    shares INTEGER NOT NULL,
    time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(id)
);